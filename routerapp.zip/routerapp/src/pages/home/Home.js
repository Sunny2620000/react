const Home = ()=>{
    return(
      <div className="component">
          Home
      </div>
  
    )  
  } 

export default Home