const Admin = ()=>{
    return (
        <div className="component">
            Admin
        </div>
    )
}

export default Admin