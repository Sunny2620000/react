const NoFound = ()=>{
 return (
    <div className="component">
        Oops Page Not Found
    </div>
 )
}

export  default NoFound;