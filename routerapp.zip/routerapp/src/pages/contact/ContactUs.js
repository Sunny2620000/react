const ContactUs = ()=>{
    return(
        <div className="component">
            ContactUs
        </div>
    )
    }
    
    export default ContactUs