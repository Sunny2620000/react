const ContactIn = ()=>{
    return(
        <div className="component">
            ContactIn
        </div>
    )
    }
    
    export default ContactIn