const ContactEr = ()=>{
return(
    <div className="component">
        ContactEr
    </div>
)
}

export default ContactEr