import { useParams } from "react-router-dom"

const ProductDetails = ()=>{
  // by object destructing we can get the name ,id value
  const {name,id} = useParams()
  console.log("name",name,"id",id);
    return(
      <div className="component">
          ProductDetails
      </div>
  
    )  
  } 

export default ProductDetails