import { useLocation, useSearchParams } from "react-router-dom"
const ProductList = ()=>{
  const [searchParams] = useSearchParams();
  const location = useLocation()
  console.log("searchparams",searchParams.get("keyword"),searchParams.get("in_stock"),"location",location)     
  return(
      <div className="component">
          ProductList
      </div>
  
    )  
  } 


export default ProductList