import { Link } from "react-router-dom"

const Footer = ()=>{
    return(
     <footer>
      <Link to="/">2030 Routemate</Link>
     </footer>
  
    )  
  } 

export default Footer