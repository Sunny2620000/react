import { Link, NavLink } from 'react-router-dom'
import logo from '../asset/logo.png'
const Header = ()=>{
    return(
     <header>
      <Link href="/" className="logo">
        <img src={logo} alt="Logo"/>
        <span>Routemate</span>
      </Link>
      <nav className="navigation">
        <NavLink to='/' className='link' end>Home</NavLink>
        <NavLink to='/products'className='link' >Products</NavLink>
        <NavLink to='/contact'className='link' >Contact</NavLink>

      </nav>
     </header>
  
    )  
  } 
export default Header