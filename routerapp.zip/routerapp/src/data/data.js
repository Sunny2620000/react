export const products = [
    {id: 1001, "name": "Product 1", "price": 149, "image": "/assets/images/placeholder.jpg",}, 
    {id: 1002, "name": "Product 2", "price": 49, "image": "/assets/images/placeholder.jpg",}, 
    {id: 1003, "name": "Product 3", "price": 179, "image": "/assets/images/placeholder.jpg",}, 
    {id: 1004, "name": "Product 4", "price": 39, "image": "/assets/images/placeholder.jpg",}, 
    {id: 1005, "name": "Product 5", "price": 199, "image": "/assets/images/placeholder.jpg",}, 
    {id: 1006, "name": "Product 6", "price": 29, "image": "/assets/images/placeholder.jpg"}
]