import {Routes,Route, Navigate} from 'react-router-dom'
import {Home,Contact,Admin,NoFound,ProductList,ProductDetail,ContactEr,ContactIn,ContactUs} from "../pages/index"
const AllRoutes = ()=>{
  const user = false;
    return(
        <>
        <Routes>
        <Route path="/" element={<Home />} />
        <Route path="products" element={<ProductList />} />
        <Route path="products/:name/:id" element={<ProductDetail />} />
        <Route path="contact" element={<Contact />}>
          <Route path="in" element={<ContactIn />} />
          <Route path="us" element={<ContactUs />} />
          <Route path="er" element={<ContactEr />} />
          <Route path="*" element={<NoFound />} />
        </Route>
        <Route path="admin" element={user ? <Admin/>:<NoFound/>} />
        <Route path="*" element={<NoFound/>} />
      </Routes>
        </>
    )
}

export default AllRoutes